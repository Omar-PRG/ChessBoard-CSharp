﻿namespace MyfinalprojectCavalier
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.settingsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.lightGrayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aliceBlueToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.greenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blackToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.buttonsColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blanchedALMONDToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.redToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.saddleBrownToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.whiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.backToMainMenuToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.learnToPlayToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.moreAboutUsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(586, 234);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 168);
            this.button4.TabIndex = 0;
            this.button4.Text = "Aleatoire";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(586, 234);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 168);
            this.button5.TabIndex = 1;
            this.button5.Text = "Rejouer";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(32, 32);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.settingsToolStripMenuItem,
            this.learnToPlayToolStripMenuItem,
            this.moreAboutUsToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Padding = new System.Windows.Forms.Padding(3, 1, 0, 1);
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 2;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // settingsToolStripMenuItem
            // 
            this.settingsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fontColorToolStripMenuItem,
            this.buttonsColorToolStripMenuItem,
            this.backToMainMenuToolStripMenuItem});
            this.settingsToolStripMenuItem.Name = "settingsToolStripMenuItem";
            this.settingsToolStripMenuItem.Size = new System.Drawing.Size(61, 22);
            this.settingsToolStripMenuItem.Text = "Settings";
            // 
            // fontColorToolStripMenuItem
            // 
            this.fontColorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.lightGrayToolStripMenuItem,
            this.redToolStripMenuItem,
            this.aliceBlueToolStripMenuItem,
            this.greenToolStripMenuItem,
            this.blackToolStripMenuItem});
            this.fontColorToolStripMenuItem.Name = "fontColorToolStripMenuItem";
            this.fontColorToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.fontColorToolStripMenuItem.Text = "Font Color";
            // 
            // lightGrayToolStripMenuItem
            // 
            this.lightGrayToolStripMenuItem.Name = "lightGrayToolStripMenuItem";
            this.lightGrayToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.lightGrayToolStripMenuItem.Text = "Light Gray";
            this.lightGrayToolStripMenuItem.Click += new System.EventHandler(this.lightGrayToolStripMenuItem_Click);
            // 
            // redToolStripMenuItem
            // 
            this.redToolStripMenuItem.Name = "redToolStripMenuItem";
            this.redToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.redToolStripMenuItem.Text = "Red";
            this.redToolStripMenuItem.Click += new System.EventHandler(this.redToolStripMenuItem_Click);
            // 
            // aliceBlueToolStripMenuItem
            // 
            this.aliceBlueToolStripMenuItem.Name = "aliceBlueToolStripMenuItem";
            this.aliceBlueToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.aliceBlueToolStripMenuItem.Text = "AliceBlue";
            this.aliceBlueToolStripMenuItem.Click += new System.EventHandler(this.aliceBlueToolStripMenuItem_Click);
            // 
            // greenToolStripMenuItem
            // 
            this.greenToolStripMenuItem.Name = "greenToolStripMenuItem";
            this.greenToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.greenToolStripMenuItem.Text = "Blue";
            this.greenToolStripMenuItem.Click += new System.EventHandler(this.greenToolStripMenuItem_Click);
            // 
            // blackToolStripMenuItem
            // 
            this.blackToolStripMenuItem.Name = "blackToolStripMenuItem";
            this.blackToolStripMenuItem.Size = new System.Drawing.Size(128, 22);
            this.blackToolStripMenuItem.Text = "Black";
            this.blackToolStripMenuItem.Click += new System.EventHandler(this.blackToolStripMenuItem_Click);
            // 
            // buttonsColorToolStripMenuItem
            // 
            this.buttonsColorToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blanchedALMONDToolStripMenuItem,
            this.grayToolStripMenuItem,
            this.redToolStripMenuItem1,
            this.saddleBrownToolStripMenuItem,
            this.whiteToolStripMenuItem});
            this.buttonsColorToolStripMenuItem.Name = "buttonsColorToolStripMenuItem";
            this.buttonsColorToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.buttonsColorToolStripMenuItem.Text = "Buttons Color";
            // 
            // blanchedALMONDToolStripMenuItem
            // 
            this.blanchedALMONDToolStripMenuItem.Name = "blanchedALMONDToolStripMenuItem";
            this.blanchedALMONDToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.blanchedALMONDToolStripMenuItem.Text = "BlanchedALMOND";
            this.blanchedALMONDToolStripMenuItem.Click += new System.EventHandler(this.blanchedALMONDToolStripMenuItem_Click);
            // 
            // grayToolStripMenuItem
            // 
            this.grayToolStripMenuItem.Name = "grayToolStripMenuItem";
            this.grayToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.grayToolStripMenuItem.Text = "Gray";
            this.grayToolStripMenuItem.Click += new System.EventHandler(this.grayToolStripMenuItem_Click);
            // 
            // redToolStripMenuItem1
            // 
            this.redToolStripMenuItem1.Name = "redToolStripMenuItem1";
            this.redToolStripMenuItem1.Size = new System.Drawing.Size(174, 22);
            this.redToolStripMenuItem1.Text = "Red";
            this.redToolStripMenuItem1.Click += new System.EventHandler(this.redToolStripMenuItem1_Click);
            // 
            // saddleBrownToolStripMenuItem
            // 
            this.saddleBrownToolStripMenuItem.Name = "saddleBrownToolStripMenuItem";
            this.saddleBrownToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.saddleBrownToolStripMenuItem.Text = "Saddle brown";
            this.saddleBrownToolStripMenuItem.Click += new System.EventHandler(this.saddleBrownToolStripMenuItem_Click);
            // 
            // whiteToolStripMenuItem
            // 
            this.whiteToolStripMenuItem.Name = "whiteToolStripMenuItem";
            this.whiteToolStripMenuItem.Size = new System.Drawing.Size(174, 22);
            this.whiteToolStripMenuItem.Text = "White";
            this.whiteToolStripMenuItem.Click += new System.EventHandler(this.whiteToolStripMenuItem_Click);
            // 
            // backToMainMenuToolStripMenuItem
            // 
            this.backToMainMenuToolStripMenuItem.Name = "backToMainMenuToolStripMenuItem";
            this.backToMainMenuToolStripMenuItem.Size = new System.Drawing.Size(177, 22);
            this.backToMainMenuToolStripMenuItem.Text = "Back to main menu";
            this.backToMainMenuToolStripMenuItem.Click += new System.EventHandler(this.backToMainMenuToolStripMenuItem_Click);
            // 
            // learnToPlayToolStripMenuItem
            // 
            this.learnToPlayToolStripMenuItem.Name = "learnToPlayToolStripMenuItem";
            this.learnToPlayToolStripMenuItem.Size = new System.Drawing.Size(87, 22);
            this.learnToPlayToolStripMenuItem.Text = "Learn to play";
            this.learnToPlayToolStripMenuItem.Click += new System.EventHandler(this.learnToPlayToolStripMenuItem_Click);
            // 
            // moreAboutUsToolStripMenuItem
            // 
            this.moreAboutUsToolStripMenuItem.Name = "moreAboutUsToolStripMenuItem";
            this.moreAboutUsToolStripMenuItem.Size = new System.Drawing.Size(155, 22);
            this.moreAboutUsToolStripMenuItem.Text = "More about Euler Method";
            this.moreAboutUsToolStripMenuItem.Click += new System.EventHandler(this.moreAboutUsToolStripMenuItem_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(800, 552);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ControlText;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form2_FormClosed);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem settingsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem lightGrayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aliceBlueToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem greenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blackToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem buttonsColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blanchedALMONDToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem redToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem saddleBrownToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem whiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem backToMainMenuToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem learnToPlayToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem moreAboutUsToolStripMenuItem;
    }
}