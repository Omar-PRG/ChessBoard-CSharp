﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Reflection.Emit;
using System.Collections.Specialized;
using System.Diagnostics;

namespace MyfinalprojectCavalier
{
    public partial class Form3 : Form
    {
        private String joueur;
        Random rnd = new Random();
        private int row;
        private int Col;
        List<int> xx = new List<int>();
        List<int> yy = new List<int>();
        private int cpt;
        bool alea = false;
        bool und, red, fin = false;

        private int x, y,step,now;
        private Image ii, il, ir;
        private int count;
        private Button[,] Echiquier;
        private Button b;
        private int a;
        private int c;
        private int redocount = 0;
        private int undocount = 0;

        public int[] arx, ary;

        public Form3()
        {
            InitializeComponent();


        }

        private void backToMainMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            {
                if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                {
                }
                else
                {

                    Form1 f1 = new Form1();
                    f1.Show();
                    Visible = false;
                }
            }
        }

        private void moreAboutEulerMethodToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.canal-math.com/construction-carres-magiques-methode-cavalier-euler");
        }

        private void learnToPlayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.pousseurdebois.fr/cours/deplacementducavalier/#:~:text=Comment%20se%20d%C3%A9place%20le%20Cavalier,en%20dessinant%20un%20L%20majuscule");


        }

        private void lightGrayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.LightGray;
        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
        }

        private void aliceBlueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.AliceBlue;
        }

        private void blueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Black;
        }

        private void blancheALMONDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.BlanchedAlmond;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.BlanchedAlmond;
                    }

                }
            }
        }

        private void grayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.Gray;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.Gray;
                    }
                }
            }
        }

        private void redToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.Red;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.Red;
                    }
                }
            }
        }

        private void saddlebrownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.SaddleBrown;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.SaddleBrown;
                    }
                }
            }
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.White;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.White;
                    }
                }
            }
        }


        private void button9_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void button9_Click_1(object sender, EventArgs e)
        {

            Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;


            if (cpt + redocount - undocount == cpt)
            {
                MessageBox.Show("No more redo available");
                Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;

            }
            else
            {
                if (radioButton1.Checked == true && radioButton2.Checked == false && radioButton3.Checked == false)
                {
                    if (cpt + redocount - undocount + 1 > cpt)
                    {
                        MessageBox.Show("No more redo available");
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;

                    }
                    else
                    {
                        redocount++;

                        Echiquier[xx[cpt + redocount - undocount - 1], yy[cpt + redocount - undocount - 1]].Image = null;
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Text = "" + (cpt + redocount - undocount);
                    }

                }
                else if (radioButton1.Checked == false && radioButton2.Checked == true && radioButton3.Checked == false)


                {
                    if (cpt + redocount - undocount + 5 > cpt)
                    {
                        MessageBox.Show("No more redo available");
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;

                    }
                    else
                    {


                        step = 5;
                        redocount += 5;
                        Echiquier[xx[cpt + redocount - undocount - 5], yy[cpt + redocount - undocount - 5]].Image = null;

                        for (int i = 0; i <= 5; i++)
                        {
                            Echiquier[xx[cpt + redocount - undocount + i - 5], yy[cpt + redocount - undocount + i - 5]].Text = "" + (cpt + redocount - undocount + i - 5);
                            if (i == 5)
                            {
                                Echiquier[xx[cpt + redocount - undocount + i - 5], yy[cpt + redocount - undocount + i - 5]].Image = ii;


                            }



                        }
                    }

                }
                else if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == true)
                {
                   /* if (> cpt)
                    {
                        MessageBox.Show("No more undo available");
                    }
                    else
                    {*/
                        now = cpt - undocount + redocount;


                        for (int i = 0; i <= Math.Abs(redocount-undocount); i++)
                        {

                            Echiquier[xx[now + i], yy[now + i]].Text = "" + (now + i);

                            Echiquier[xx[now + i], yy[now + i]].Image = null;

                        }


                    redocount += Math.Abs(redocount - undocount);
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;
                  //  Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Text =""+(now+;

                }


                label11.Text = Convert.ToString(redocount);


                        for (int l = 0; l < 8; l++)
                        {
                            for (int c = 0; c < 8; c++)
                            {
                                Echiquier[x, y].Image = null;
                                if (Echiquier[l, c].Text != "" && Echiquier[l, c].Text != "Here")
                                {
                                    Echiquier[l, c].Enabled = false;

                                }

                                else
                                {

                                    if (Echiquier[l, c].Text == "Here")
                                    {
                                        Echiquier[l, c].Enabled = false;
                                        Echiquier[l, c].Text = "";               //suppression des cases "Here" et d cavalier de la case en cours
                                    }

                                    else if (Echiquier[l, c].Text == "")
                                    {
                                        Echiquier[l, c].Text = "";
                                        Echiquier[l, c].Enabled = false;

                                    }


                                }


                            }
                        }

                        y = xx[cpt + redocount - undocount];
                        x = yy[cpt + redocount - undocount];


                        if (x + 1 <= 7 && y - 2 >= 0)

                        {
                            if (!(Echiquier[y - 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x + 1].Text == "")
                            {
                                Echiquier[y - 2, x + 1].Text = "Here";
                                Echiquier[y - 2, x + 1].Enabled = true;
                                count++;
                            }
                            else
                            {
                                //Echiquier[y - 2, x + 1].Text = "x";
                                Echiquier[y - 2, x + 1].Enabled = false;

                            }
                        }
                        if (x + 2 <= 7 && y - 1 >= 0)

                        {
                            if (!(Echiquier[y - 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x + 2].Text == "")
                            {
                                Echiquier[y - 1, x + 2].Text = "Here";
                                Echiquier[y - 1, x + 2].Enabled = true;
                                count++;
                            }
                            else
                            {
                                //Echiquier[y - 1, x + 2].Text = "x";
                                Echiquier[y - 1, x + 2].Enabled = false;

                            }

                        }
                        if (x + 2 <= 7 && y + 1 <= 7)

                        {
                            if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                            {
                                Echiquier[y + 1, x + 2].Text = "Here";
                                Echiquier[y + 1, x + 2].Enabled = true;
                                count++;
                            }
                            else
                            {
                                // Echiquier[y + 1, x + 2].Text = "x";
                                Echiquier[y + 1, x + 2].Enabled = false;

                            }
                        }
                        if (x - 2 >= 0 && y - 1 >= 0)

                        {
                            if (!(Echiquier[y - 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x - 2].Text == "")
                            {
                                Echiquier[y - 1, x - 2].Text = "Here";
                                Echiquier[y - 1, x - 2].Enabled = true;
                                count++;
                            }
                            else
                            {
                                //Echiquier[y - 1, x - 2].Text = "x";
                                Echiquier[y - 1, x - 2].Enabled = false;

                            }

                        }
                        if (x - 2 >= 0 && y + 1 <= 7)
                        {
                            if (!(Echiquier[y + 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x - 2].Text == "")
                            {
                                Echiquier[y + 1, x - 2].Text = "Here";
                                Echiquier[y + 1, x - 2].Enabled = true;
                                count++;
                            }
                            else
                            {
                                // Echiquier[y + 1, x - 2].Text = "x";
                                Echiquier[y + 1, x - 2].Enabled = false;

                            }

                        }
                        if (x - 1 >= 0 && y + 2 <= 7)
                        {
                            if (!(Echiquier[y + 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x - 1].Text == "")

                            {
                                Echiquier[y + 2, x - 1].Text = "Here";
                                Echiquier[y + 2, x - 1].Enabled = true;
                                count++;
                            }
                            else
                            {
                                //   Echiquier[y + 2, x - 1].Text = "x";
                                Echiquier[y + 2, x - 1].Enabled = false;

                            }
                        }
                        if (x - 1 >= 0 && y - 2 >= 0)
                        {

                            if (!(Echiquier[y - 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x - 1].Text == "")
                            {

                                Echiquier[y - 2, x - 1].Text = "Here";
                                Echiquier[y - 2, x - 1].Enabled = true;
                                count++;

                            }
                            else
                            {
                                //   Echiquier[y - 2, x - 1].Text = "x";
                                Echiquier[y - 2, x - 1].Enabled = false;

                            }
                        }
                        if (x + 1 <= 7 && y + 2 <= 7)
                        {


                            if (!(Echiquier[y + 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x + 1].Text == "")
                            {

                                Echiquier[y + 2, x + 1].Text = "Here";
                                Echiquier[y + 2, x + 1].Enabled = true;
                                count++;

                            }
                            else
                            {
                                //  Echiquier[y + 2, x + 1].Text = "x";
                                Echiquier[y + 2, x + 1].Enabled = false;

                            }
                        }

                        if (x + 2 <= 7 && y + 1 <= 7)
                        {


                            if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                            {

                                Echiquier[y + 1, x + 2].Text = "Here";
                                Echiquier[y + 1, x + 2].Enabled = true;
                                count++;

                            }
                            else
                            {
                                //  Echiquier[y + 1, x + 2].Text = "x";
                                Echiquier[y + 1, x + 2].Enabled = false;


                            }

                        }








                    }

                }
           
        

        private void button1_Click_1(object sender, EventArgs e)
        {
            SimulationStart();
            
            button1.Enabled = false;    
        }

        private void SimulationStart()                                                                                           //Simulation start
        {
            button9.Enabled = true;
            button8.Enabled = true;
            und = false;
            red=false;
            Echiquier[y, x].Image = null;
            while (count!=0)
            {

                
                if (radioButton1.Checked == true || radioButton2.Checked == true || radioButton3.Checked == true)

                {

                    y = rnd.Next(8);//row
                    x = rnd.Next(8);//col
                    while (!(Echiquier[x, y].Text == "Here" && Echiquier[x, y].Text != "" && !(Echiquier[x, y].Text.All(char.IsDigit))))

                    {
                        y = rnd.Next(8);//row
                        x = rnd.Next(8);//col

                    }
                    label5.Text = Convert.ToString(x);//col
                    label6.Text = Convert.ToString(y); //row
                                                       //Echiquier[x, y].Text = "moi";
                } 
                

                if (Echiquier[x, y].Text == "Here" && Echiquier[x, y].Text != "" && !(Echiquier[x, y].Text.All(char.IsDigit)))
                {   
                    Echiquier[x, y].Enabled = false;
                    
                    Echiquier[x, y].Text = "";
                    Echiquier[x, y].Text = "" + cpt;
                   // Thread.Sleep(300);
                    xx.Add(x);
                    yy.Add(y);
                    //ary[cpt] = y;
                    for (int l = 0; l < 8; l++)
                    {
                        for (int c = 0; c < 8; c++)
                        {
                            Echiquier[x, y].Image = null;
                            if (Echiquier[l, c].Text != "" && Echiquier[l, c].Text != "Here")
                            {
                                Echiquier[l, c].Enabled = false;

                            }

                            else
                            {

                                if (Echiquier[l, c].Text == "Here")
                                {
                                    Echiquier[l, c].Enabled = false;
                                    Echiquier[l, c].Text = "";               //preparation de l'Echiquier.
                                }

                                else if (Echiquier[l, c].Text == "")
                                {
                                    Echiquier[l, c].Text = "";
                                    Echiquier[l, c].Enabled = false;

                                }




                            }
                        }




                    }
                }
                Echiquier[x, y].Image = null;

                //jusqua ici tout va bien
                a = x;
                x = y;
                c = y;
                y = a;
              
                count = 0;

                if (x + 1 <= 7 && y - 2 >= 0)

                {
                    if (!(Echiquier[y - 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x + 1].Text == "")
                    {
                        Echiquier[y - 2, x + 1].Text = "Here";
                        Echiquier[y - 2, x + 1].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 2, x + 1].Text = "x";
                        Echiquier[y - 2, x + 1].Enabled = false;

                    }
                }
                if (x + 2 <= 7 && y - 1 >= 0)

                {
                    if (!(Echiquier[y - 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x + 2].Text == "")
                    {
                        Echiquier[y - 1, x + 2].Text = "Here";
                        Echiquier[y - 1, x + 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 1, x + 2].Text = "x";
                        Echiquier[y - 1, x + 2].Enabled = false;

                    }

                }
                if (x + 2 <= 7 && y + 1 <= 7)

                {
                    if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                    {
                        Echiquier[y + 1, x + 2].Text = "Here";
                        Echiquier[y + 1, x + 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        // Echiquier[y + 1, x + 2].Text = "x";
                        Echiquier[y + 1, x + 2].Enabled = false;

                    }
                }
                if (x - 2 >= 0 && y - 1 >= 0)

                {
                    if (!(Echiquier[y - 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x - 2].Text == "")
                    {
                        Echiquier[y - 1, x - 2].Text = "Here";
                        Echiquier[y - 1, x - 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 1, x - 2].Text = "x";
                        Echiquier[y - 1, x - 2].Enabled = false;

                    }

                }
                if (x - 2 >= 0 && y + 1 <= 7)
                {
                    if (!(Echiquier[y + 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x - 2].Text == "")
                    {
                        Echiquier[y + 1, x - 2].Text = "Here";
                        Echiquier[y + 1, x - 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        // Echiquier[y + 1, x - 2].Text = "x";
                        Echiquier[y + 1, x - 2].Enabled = false;

                    }

                }
                if (x - 1 >= 0 && y + 2 <= 7)
                {
                    if (!(Echiquier[y + 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x - 1].Text == "")

                    {
                        Echiquier[y + 2, x - 1].Text = "Here";
                        Echiquier[y + 2, x - 1].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //   Echiquier[y + 2, x - 1].Text = "x";
                        Echiquier[y + 2, x - 1].Enabled = false;

                    }
                }
                if (x - 1 >= 0 && y - 2 >= 0)
                {

                    if (!(Echiquier[y - 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x - 1].Text == "")
                    {

                        Echiquier[y - 2, x - 1].Text = "Here";
                        Echiquier[y - 2, x - 1].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //   Echiquier[y - 2, x - 1].Text = "x";
                        Echiquier[y - 2, x - 1].Enabled = false;

                    }
                }
                if (x + 1 <= 7 && y + 2 <= 7)
                {


                    if (!(Echiquier[y + 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x + 1].Text == "")
                    {

                        Echiquier[y + 2, x + 1].Text = "Here";
                        Echiquier[y + 2, x + 1].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //  Echiquier[y + 2, x + 1].Text = "x";
                        Echiquier[y + 2, x + 1].Enabled = false;

                    }
                }

                if (x + 2 <= 7 && y + 1 <= 7)
                {


                    if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                    {

                        Echiquier[y + 1, x + 2].Text = "Here";
                        Echiquier[y + 1, x + 2].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //  Echiquier[y + 1, x + 2].Text = "x";
                        Echiquier[y + 1, x + 2].Enabled = false;

                    }

                }

               cpt++;
               Echiquier[a,c].Image = null;;

            }
            cpt--;
            fin = true;
            if (fin==true)
            
            {
                label12.Text = Convert.ToString(cpt);
                Echiquier[a,c].Image = ii; 
           
            
            }


             


        }



        private void Form3_Load(object sender, EventArgs e)
        {







            button9.Enabled = false;
            button8.Enabled = false;
            step = 0;
            cpt = 0;
            label10.Text = Convert.ToString(undocount);
            label11.Text = Convert.ToString(redocount);
            label12.Text = Convert.ToString(cpt);

            radioButton1.Checked = true;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
         
          
            ii = Image.FromFile("image\\Cavalier.png");
             
            
                this.Size = new Size(920, 650);
                Echiquier = new Button[8, 8];



                for (int l = 0; l < 8; l++)
                {
                    for (int c = 0; c < 8; c++)
                    {
                        Button b;
                        b = new Button();
                        b.Location = new Point(l * 70, c * 70);
                        b.Size = new Size(70, 70);
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                       b.BackColor = Color.White;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        b.BackColor = Color.White;
                    }

                
                      

                        b.Text = "";

                        this.Controls.Add(b);
                        Echiquier[l, c] = b;

                        b.Top += 30;

                    }

                }

                cpt = 0;
                firstpoint();

            }

            private void button7_Click(object sender, EventArgs e)
            {
            cpt = 0;
            button1.Enabled = true;
            button9.Enabled = false;
            button8.Enabled = false;
            // button7.Visible = aleatoire;

            //  button7.Visible = false;
             redocount = 0;
             undocount = 0;

                 xx.Clear();
                 yy.Clear();
            label11.Text = "0";
            label10.Text = "0";
            cpt = 0;

                for (int l = 0; l < 8; l++)
                    for (int c = 0; c < 8; c++)                                                         //Restart
                    {
                        Echiquier[l, c].Text = "";
                        Echiquier[l, c].Enabled = true;
                        Echiquier[l, c].Image = null;

                    }

                firstpoint();
            }

        

        private void Form3_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            

            if (cpt + redocount - undocount == 0 ||cpt==1)
            {
                MessageBox.Show("No more undo available");
                Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;

            }
            else
            {
                if (radioButton1.Checked == true && radioButton2.Checked == false && radioButton3.Checked == false)
                {
                    step = 1;
                    undocount++;
                    Echiquier[xx[cpt + redocount - undocount + 1], yy[cpt + redocount - undocount + 1]].Text = "";
                    Echiquier[xx[cpt + redocount - undocount + 1], yy[cpt + redocount - undocount + 1]].Image = null;
                    Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;
                    Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Text = "" + (cpt + redocount - undocount);


                }
                else if (radioButton1.Checked == false && radioButton2.Checked == true && radioButton3.Checked == false)


                {
                    if (cpt + redocount - undocount - 5 < 0)
                    {
                        MessageBox.Show("No more undo available");
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;

                    }
                    else
                    {


                        step = 5;
                        undocount += 5;
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Image = ii;
                        Echiquier[xx[cpt + redocount - undocount], yy[cpt + redocount - undocount]].Text = "" + (cpt + redocount - undocount);
                        for (int i = 0; i < 5; i++)
                        {
                            Echiquier[xx[cpt + redocount - undocount - i + 5], yy[cpt + redocount - undocount - i + 5]].Text = "";

                            Echiquier[xx[cpt + redocount - undocount - i + 5], yy[cpt + redocount - undocount - i + 5]].Image = null;


                        }
                    }

                }
                else if (radioButton1.Checked == false && radioButton2.Checked == false && radioButton3.Checked == true)

                {
                    now= cpt - undocount + redocount;
                    
                    


                    for (int i = 0; i <now; i++)
                    {

                        Echiquier[xx[now-i], yy[now- i]].Text = "";

                        Echiquier[xx[now- i], yy[now- i]].Image = null ;



                        //Echiquier[xx[step - i], yy[step - i]].Text = "";

                      //  Echiquier[xx[step - i], yy[step - i]].Image = null;


                    }


                    undocount += now;
                    Echiquier[xx[cpt+redocount-undocount], yy[cpt+redocount-undocount]].Image = ii;
                }

                for (int l = 0; l < 8; l++)
                {
                    for (int c = 0; c < 8; c++)
                    {
                        Echiquier[x, y].Image = null;
                        if (Echiquier[l, c].Text != "" && Echiquier[l, c].Text != "Here")
                        {
                            Echiquier[l, c].Enabled = false;

                        }

                        else
                        {

                            if (Echiquier[l, c].Text == "Here")
                            {
                                Echiquier[l, c].Enabled = false;
                                Echiquier[l, c].Text = "";               //suppression des cases "Here" et d cavalier de la case en cours
                            }

                            else if (Echiquier[l, c].Text == "")
                            {
                                Echiquier[l, c].Text = "";
                                Echiquier[l, c].Enabled = false;

                            }


                        }


                    }
                }
          
                    y = xx[cpt - undocount+redocount];
                    x = yy[cpt - undocount+redocount];
                    label5.Text = Convert.ToString(y);//col
                    label6.Text = Convert.ToString(x); //row
              
               
                if (x + 1 <= 7 && y - 2 >= 0)

                {
                    if (!(Echiquier[y - 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x + 1].Text == "")
                    {
                        Echiquier[y - 2, x + 1].Text = "Here";
                        Echiquier[y - 2, x + 1].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 2, x + 1].Text = "x";
                        Echiquier[y - 2, x + 1].Enabled = false;

                    }
                }
                if (x + 2 <= 7 && y - 1 >= 0)

                {
                    if (!(Echiquier[y - 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x + 2].Text == "")
                    {
                        Echiquier[y - 1, x + 2].Text = "Here";
                        Echiquier[y - 1, x + 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 1, x + 2].Text = "x";
                        Echiquier[y - 1, x + 2].Enabled = false;

                    }

                }
                if (x + 2 <= 7 && y + 1 <= 7)

                {
                    if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                    {
                        Echiquier[y + 1, x + 2].Text = "Here";
                        Echiquier[y + 1, x + 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        // Echiquier[y + 1, x + 2].Text = "x";
                        Echiquier[y + 1, x + 2].Enabled = false;

                    }
                }
                if (x - 2 >= 0 && y - 1 >= 0)

                {
                    if (!(Echiquier[y - 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x - 2].Text == "")
                    {
                        Echiquier[y - 1, x - 2].Text = "Here";
                        Echiquier[y - 1, x - 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 1, x - 2].Text = "x";
                        Echiquier[y - 1, x - 2].Enabled = false;

                    }

                }
                if (x - 2 >= 0 && y + 1 <= 7)
                {
                    if (!(Echiquier[y + 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x - 2].Text == "")
                    {
                        Echiquier[y + 1, x - 2].Text = "Here";
                        Echiquier[y + 1, x - 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        // Echiquier[y + 1, x - 2].Text = "x";
                        Echiquier[y + 1, x - 2].Enabled = false;

                    }

                }
                if (x - 1 >= 0 && y + 2 <= 7)
                {
                    if (!(Echiquier[y + 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x - 1].Text == "")

                    {
                        Echiquier[y + 2, x - 1].Text = "Here";
                        Echiquier[y + 2, x - 1].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //   Echiquier[y + 2, x - 1].Text = "x";
                        Echiquier[y + 2, x - 1].Enabled = false;

                    }
                }
                if (x - 1 >= 0 && y - 2 >= 0)
                {

                    if (!(Echiquier[y - 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x - 1].Text == "")
                    {

                        Echiquier[y - 2, x - 1].Text = "Here";
                        Echiquier[y - 2, x - 1].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //   Echiquier[y - 2, x - 1].Text = "x";
                        Echiquier[y - 2, x - 1].Enabled = false;

                    }
                }
                if (x + 1 <= 7 && y + 2 <= 7)
                {


                    if (!(Echiquier[y + 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x + 1].Text == "")
                    {

                        Echiquier[y + 2, x + 1].Text = "Here";
                        Echiquier[y + 2, x + 1].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //  Echiquier[y + 2, x + 1].Text = "x";
                        Echiquier[y + 2, x + 1].Enabled = false;

                    }
                }

                if (x + 2 <= 7 && y + 1 <= 7)
                {


                    if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                    {

                        Echiquier[y + 1, x + 2].Text = "Here";
                        Echiquier[y + 1, x + 2].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //  Echiquier[y + 1, x + 2].Text = "x";
                        Echiquier[y + 1, x + 2].Enabled = false;


                    }

                }

            }

            label10.Text = Convert.ToString(undocount);



        }


        private void firstpoint()
        {
            redocount = 0;
            undocount = 0;
            label12.Text = Convert.ToString(cpt);

            row = rnd.Next(8);
            Col = rnd.Next(8);
            x = row;
            y = Col;

           
            xx.Add(y);
            yy.Add(x);
            label5.Text = Convert.ToString(y);
            label6.Text = Convert.ToString(x);
            Echiquier[Col, row].Text = "" + cpt;
            Echiquier[Col, row].Enabled = false;
            ii = Image.FromFile("image\\Cavalier.png");
            Echiquier[Col, row].Image=ii;
            cpt++;
            alea = true;
            if (x + 1 <= 7 && y - 2 >= 0)

            {
                if (!(Echiquier[y - 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x + 1].Text == "")
                {
                    Echiquier[y - 2, x + 1].Text = "Here";
                    Echiquier[y - 2, x + 1].Enabled = true;
                    count++;
                }
                else
                {
                    //Echiquier[y - 2, x + 1].Text = "x";
                    Echiquier[y - 2, x + 1].Enabled = false;

                }
            }
            if (x + 2 <= 7 && y - 1 >= 0)                                                                                                       //First step with here texts

            {
                if (!(Echiquier[y - 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x + 2].Text == "")
                {
                    Echiquier[y - 1, x + 2].Text = "Here";
                    Echiquier[y - 1, x + 2].Enabled = true;
                    count++;
                }
                else
                {
                    //Echiquier[y - 1, x + 2].Text = "x";
                    Echiquier[y - 1, x + 2].Enabled = false;

                }

            }
            if (x + 2 <= 7 && y + 1 <= 7)

            {
                if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                {
                    Echiquier[y + 1, x + 2].Text = "Here";
                    Echiquier[y + 1, x + 2].Enabled = true;
                    count++;
                }
                else
                {
                    // Echiquier[y + 1, x + 2].Text = "x";
                    Echiquier[y + 1, x + 2].Enabled = false;

                }
            }
            if (x - 2 >= 0 && y - 1 >= 0)

            {
                if (!(Echiquier[y - 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x - 2].Text == "")
                {
                    Echiquier[y - 1, x - 2].Text = "Here";
                    Echiquier[y - 1, x - 2].Enabled = true;
                    count++;
                }
                else
                {
                    //Echiquier[y - 1, x - 2].Text = "x";
                    Echiquier[y - 1, x - 2].Enabled = false;

                }

            }
            if (x - 2 >= 0 && y + 1 <= 7)
            {
                if (!(Echiquier[y + 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x - 2].Text == "")
                {
                    Echiquier[y + 1, x - 2].Text = "Here";
                    Echiquier[y + 1, x - 2].Enabled = true;
                    count++;
                }
                else
                {
                    // Echiquier[y + 1, x - 2].Text = "x";
                    Echiquier[y + 1, x - 2].Enabled = false;

                }

            }
            if (x - 1 >= 0 && y + 2 <= 7)
            {
                if (!(Echiquier[y + 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x - 1].Text == "")

                {
                    Echiquier[y + 2, x - 1].Text = "Here";
                    Echiquier[y + 2, x - 1].Enabled = true;
                    count++;
                }
                else
                {
                    //   Echiquier[y + 2, x - 1].Text = "x";
                    Echiquier[y + 2, x - 1].Enabled = false;

                }
            }
            if (x - 1 >= 0 && y - 2 >= 0)
            {

                if (!(Echiquier[y - 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x - 1].Text == "")
                {

                    Echiquier[y - 2, x - 1].Text = "Here";
                    Echiquier[y - 2, x - 1].Enabled = true;
                    count++;

                }
                else
                {
                    //   Echiquier[y - 2, x - 1].Text = "x";
                    Echiquier[y - 2, x - 1].Enabled = false;

                }
            }
            if (x + 1 <= 7 && y + 2 <= 7)
            {


                if (!(Echiquier[y + 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x + 1].Text == "")
                {

                    Echiquier[y + 2, x + 1].Text = "Here";
                    Echiquier[y + 2, x + 1].Enabled = true;
                    count++;

                }
                else
                {
                    //  Echiquier[y + 2, x + 1].Text = "x";
                    Echiquier[y + 2, x + 1].Enabled = false;

                }
            }

            if (x + 2 <= 7 && y + 1 <= 7)
            {


                if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                {

                    Echiquier[y + 1, x + 2].Text = "Here";
                    Echiquier[y + 1, x + 2].Enabled = true;
                    count++;

                }
                else
                {
                    //  Echiquier[y + 1, x + 2].Text = "x";
                    Echiquier[y + 1, x + 2].Enabled = false;

                }
               
            }
        
        }



    } }
    

