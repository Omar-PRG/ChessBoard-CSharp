﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MyfinalprojectCavalier
{
    public partial class Form2 : Form
    {
        private String joueur;
        Random rnd = new Random();
        private int row;
        private int Col;
        private int cpt;
        bool aleatoire;
        private int x, y;
        private Image il;
        private int count;
        private Button[,] Echiquier;
        private Button b;
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            button4.Visible = true;    
            button5.Visible = true;
            aleatoire = false;
            il = Image.FromFile("image\\Cavalier.png");
            this.Size = new Size(750, 640);
            Echiquier = new Button[8, 8];



            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    Button b;
                    b = new Button();
                    b.Location = new Point(l * 70, c * 70);
                    b.Size = new Size(70, 70);
                    //b.AutoSize = true;
                    if (l%2==0 && c%2!=0)
                    {
                        b.BackColor = Color.White;

                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        b.BackColor = Color.White;

                    }

                    b.Text = "";

                    this.Controls.Add(b);
                    Echiquier[l, c] = b;

                    b.Top += 30;
                    b.Click += Grid_Click;
                }

            }

            button5.Text = "REJOUER ?";
            button5.Visible = false;
            cpt = 0;
        }

        private void Form2_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            button4.Visible = true;

            button5.Visible = false;


            cpt = 0;

            for (int l = 0; l < 8; l++)
                for (int c = 0; c < 8; c++)
                {
                    Echiquier[l, c].Text = "";
                    Echiquier[l, c].Enabled = true;
                    Echiquier[l, c].Image = null;

                }
        }

        private void button4_Click(object sender, EventArgs e)
        {

            button4.Visible = false;
                aleatoire = true;
                row = rnd.Next(8);
                Col = rnd.Next(8);
                Echiquier[Col, row].Text = "" + cpt;
                Echiquier[Col, row].Enabled = false;
                il = Image.FromFile("image\\Cavalier.png");
                Echiquier[Col, row].Image = il;
                x = row;
                y = Col;
                cpt++;
                for (int l = 0; l < 8; l++)
                    for (int c = 0; c < 8; c++)
                    {
                        //Echiquier[l, c].Image = null;
                        if (Echiquier[l, c].Text != "" && Echiquier[l, c].Text != "Here")
                        {
                            Echiquier[l, c].Enabled = false;


                        }
                        else
                        {

                            if (Echiquier[l, c].Text == "Here")
                            {
                                Echiquier[l, c].Enabled = false;
                                Echiquier[l, c].Text = "";
                            }

                            else if (Echiquier[l, c].Text == "")
                            {
                                Echiquier[l, c].Text = "";
                                Echiquier[l, c].Enabled = false;

                            }

                        }


                    }
                if (x + 1 <= 7 && y - 2 >= 0)

                {
                    if (!(Echiquier[y - 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x + 1].Text == "")
                    {
                        Echiquier[y - 2, x + 1].Text = "Here";
                        Echiquier[y - 2, x + 1].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 2, x + 1].Text = "x";
                        Echiquier[y - 2, x + 1].Enabled = false;

                    }
                }
                if (x + 2 <= 7 && y - 1 >= 0)

                {
                    if (!(Echiquier[y - 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x + 2].Text == "")
                    {
                        Echiquier[y - 1, x + 2].Text = "Here";
                        Echiquier[y - 1, x + 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 1, x + 2].Text = "x";
                        Echiquier[y - 1, x + 2].Enabled = false;

                    }

                }
                if (x + 2 <= 7 && y + 1 <= 7)

                {
                    if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                    {
                        Echiquier[y + 1, x + 2].Text = "Here";
                        Echiquier[y + 1, x + 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        // Echiquier[y + 1, x + 2].Text = "x";
                        Echiquier[y + 1, x + 2].Enabled = false;

                    }
                }
                if (x - 2 >= 0 && y - 1 >= 0)

                {
                    if (!(Echiquier[y - 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x - 2].Text == "")
                    {
                        Echiquier[y - 1, x - 2].Text = "Here";
                        Echiquier[y - 1, x - 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //Echiquier[y - 1, x - 2].Text = "x";
                        Echiquier[y - 1, x - 2].Enabled = false;

                    }

                }
                if (x - 2 >= 0 && y + 1 <= 7)
                {
                    if (!(Echiquier[y + 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x - 2].Text == "")
                    {
                        Echiquier[y + 1, x - 2].Text = "Here";
                        Echiquier[y + 1, x - 2].Enabled = true;
                        count++;
                    }
                    else
                    {
                        // Echiquier[y + 1, x - 2].Text = "x";
                        Echiquier[y + 1, x - 2].Enabled = false;

                    }

                }
                if (x - 1 >= 0 && y + 2 <= 7)
                {
                    if (!(Echiquier[y + 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x - 1].Text == "")

                    {
                        Echiquier[y + 2, x - 1].Text = "Here";
                        Echiquier[y + 2, x - 1].Enabled = true;
                        count++;
                    }
                    else
                    {
                        //   Echiquier[y + 2, x - 1].Text = "x";
                        Echiquier[y + 2, x - 1].Enabled = false;

                    }
                }
                if (x - 1 >= 0 && y - 2 >= 0)
                {

                    if (!(Echiquier[y - 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x - 1].Text == "")
                    {

                        Echiquier[y - 2, x - 1].Text = "Here";
                        Echiquier[y - 2, x - 1].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //   Echiquier[y - 2, x - 1].Text = "x";
                        Echiquier[y - 2, x - 1].Enabled = false;

                    }
                }
                if (x + 1 <= 7 && y + 2 <= 7)
                {


                    if (!(Echiquier[y + 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x + 1].Text == "")
                    {

                        Echiquier[y + 2, x + 1].Text = "Here";
                        Echiquier[y + 2, x + 1].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //  Echiquier[y + 2, x + 1].Text = "x";
                        Echiquier[y + 2, x + 1].Enabled = false;

                    }
                }


                if (x + 2 <= 7 && y + 1 <= 7)
                {


                    if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                    {

                        Echiquier[y + 1, x + 2].Text = "Here";
                        Echiquier[y + 1, x + 2].Enabled = true;
                        count++;

                    }
                    else
                    {
                        //  Echiquier[y + 1, x + 2].Text = "x";
                        Echiquier[y + 1, x + 2].Enabled = false;

                    }

                }
                Echiquier[Col, row].Click += Grid_Click;
            }

        private void lightGrayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.LightGray;
        }

        private void redToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Red;
        }

        private void aliceBlueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.AliceBlue;
        }

        private void blackToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Black;
        }

        private void greenToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.BackColor = Color.Blue;
        }

        private void blanchedALMONDToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.BlanchedAlmond;

                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.BlanchedAlmond;

                    }
                }
            }
        }

        private void grayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.Gray;

                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.Gray;

                    }
                    
                }
            }
        }

        private void redToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.Red;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.Red;
                    }
                   
                }
            }
        }

        private void saddleBrownToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {
                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.SaddleBrown;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.SaddleBrown;
                    }

                }
            }
        }

        private void whiteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            for (int l = 0; l < 8; l++)
            {
                for (int c = 0; c < 8; c++)
                {

                    if (l % 2 == 0 && c % 2 != 0)
                    {
                        Echiquier[l, c].BackColor = Color.White;
                    }
                    if (l % 2 != 0 && c % 2 == 0)
                    {
                        Echiquier[l, c].BackColor = Color.White;
                    }

                }
            }
            
        }

        private void backToMainMenuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are you sure you want to exit?", "Confirm exit", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
            {
            }
            else 
            {

                Form1 f1 = new Form1();
                f1.Show();
                Visible = false;
            }
        }

        private void learnToPlayToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.pousseurdebois.fr/cours/deplacementducavalier/#:~:text=Comment%20se%20d%C3%A9place%20le%20Cavalier,en%20dessinant%20un%20L%20majuscule");
        }

        private void moreAboutUsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start("https://www.canal-math.com/construction-carres-magiques-methode-cavalier-euler");
    
        }

        private void Grid_Click(object sender, EventArgs e)
            {
                button4.Visible = false;
                if (sender is Button)
                {
                for (int l = 0; l < 8; l++)
                {
                    for (int c = 0; c < 8; c++)
                    {
                        Echiquier[l, c].Image = null;
                        if (Echiquier[l, c].Text != "" && Echiquier[l, c].Text != "Here")
                        {
                            Echiquier[l, c].Enabled = false;


                        }
                        else
                        {

                            if (Echiquier[l, c].Text == "Here")
                            {
                                Echiquier[l, c].Enabled = false;
                                Echiquier[l, c].Text = "";
                            }

                            else if (Echiquier[l, c].Text == "")
                            {
                                Echiquier[l, c].Text = "";
                                Echiquier[l, c].Enabled = false;

                            }

                        }


                    }
                  
                }  count = 0;
                    b = sender as Button;
                    b.Text = "" + cpt;

                    bool isIntString = "your string".All(char.IsDigit);
                    b.Enabled = false;
                    cpt++;
                    b.Image = il;

                    y = (b.Location.X) / 70;
                    x = (b.Location.Y) / 70;

                    //label1.Text = Convert.ToString(x);
                    //label2.Text = Convert.ToString(y);
                    if (x + 1 <= 7 && y - 2 >= 0)

                    {
                        if (!(Echiquier[y - 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x + 1].Text == "")
                        {
                            Echiquier[y - 2, x + 1].Text = "Here";
                            Echiquier[y - 2, x + 1].Enabled = true;
                            count++;
                        }
                        else
                        {
                            //Echiquier[y - 2, x + 1].Text = "x";
                            Echiquier[y - 2, x + 1].Enabled = false;

                        }
                    }
                    if (x + 2 <= 7 && y - 1 >= 0)

                    {
                        if (!(Echiquier[y - 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x + 2].Text == "")
                        {
                            Echiquier[y - 1, x + 2].Text = "Here";
                            Echiquier[y - 1, x + 2].Enabled = true;
                            count++;
                        }
                        else
                        {
                            //Echiquier[y - 1, x + 2].Text = "x";
                            Echiquier[y - 1, x + 2].Enabled = false;

                        }

                    }
                    if (x + 2 <= 7 && y + 1 <= 7)

                    {
                        if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                        {
                            Echiquier[y + 1, x + 2].Text = "Here";
                            Echiquier[y + 1, x + 2].Enabled = true;
                            count++;
                        }
                        else
                        {
                            // Echiquier[y + 1, x + 2].Text = "x";
                            Echiquier[y + 1, x + 2].Enabled = false;

                        }
                    }
                    if (x - 2 >= 0 && y - 1 >= 0)

                    {
                        if (!(Echiquier[y - 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y - 1, x - 2].Text == "")
                        {
                            Echiquier[y - 1, x - 2].Text = "Here";
                            Echiquier[y - 1, x - 2].Enabled = true;
                            count++;
                        }
                        else
                        {
                            //Echiquier[y - 1, x - 2].Text = "x";
                            Echiquier[y - 1, x - 2].Enabled = false;

                        }

                    }
                    if (x - 2 >= 0 && y + 1 <= 7)
                    {
                        if (!(Echiquier[y + 1, x - 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x - 2].Text == "")
                        {
                            Echiquier[y + 1, x - 2].Text = "Here";
                            Echiquier[y + 1, x - 2].Enabled = true;
                            count++;
                        }
                        else
                        {
                            // Echiquier[y + 1, x - 2].Text = "x";
                            Echiquier[y + 1, x - 2].Enabled = false;

                        }

                    }
                    if (x - 1 >= 0 && y + 2 <= 7)
                    {
                        if (!(Echiquier[y + 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x - 1].Text == "")

                        {
                            Echiquier[y + 2, x - 1].Text = "Here";
                            Echiquier[y + 2, x - 1].Enabled = true;
                            count++;
                        }
                        else
                        {
                            //   Echiquier[y + 2, x - 1].Text = "x";
                            Echiquier[y + 2, x - 1].Enabled = false;

                        }
                    }
                    if (x - 1 >= 0 && y - 2 >= 0)
                    {

                        if (!(Echiquier[y - 2, x - 1].Text.All(char.IsDigit)) || Echiquier[y - 2, x - 1].Text == "")
                        {

                            Echiquier[y - 2, x - 1].Text = "Here";
                            Echiquier[y - 2, x - 1].Enabled = true;
                            count++;

                        }
                        else
                        {
                            //   Echiquier[y - 2, x - 1].Text = "x";
                            Echiquier[y - 2, x - 1].Enabled = false;

                        }
                    }
                    if (x + 1 <= 7 && y + 2 <= 7)
                    {


                        if (!(Echiquier[y + 2, x + 1].Text.All(char.IsDigit)) || Echiquier[y + 2, x + 1].Text == "")
                        {

                            Echiquier[y + 2, x + 1].Text = "Here";
                            Echiquier[y + 2, x + 1].Enabled = true;
                            count++;

                        }
                        else
                        {
                            //  Echiquier[y + 2, x + 1].Text = "x";
                            Echiquier[y + 2, x + 1].Enabled = false;

                        }
                    }





                    if (x + 2 <= 7 && y + 1 <= 7)
                    {


                        if (!(Echiquier[y + 1, x + 2].Text.All(char.IsDigit)) || Echiquier[y + 1, x + 2].Text == "")
                        {

                            Echiquier[y + 1, x + 2].Text = "Here";
                            Echiquier[y + 1, x + 2].Enabled = true;
                            count++;

                        }
                        else
                        {
                            //  Echiquier[y + 1, x + 2].Text = "x";
                            Echiquier[y + 1, x + 2].Enabled = false;

                        }

                    }


                }



                if (cpt == 64 || count == 0)
                {
                    // label1.Text = "MATCH NUL !!!";
                   button4.Visible = false;
                   button5.Visible = true;

                }
            }
        }

       
    }

